git pull && rm -rf .git && git init
