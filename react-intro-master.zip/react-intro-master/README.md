# Lectrum corporate React course boilerplate

## In order to start a project follow these steps:

+ `git clone git@github.com:Lectrum/react-corporate-boilerplate.git`
+ `cd react-corporate-boilerplate`
+ `npm i` or `yarn`
+ `npm start` or `yarn start`

## Or using a one-liner:

+ `git clone git@github.com:Lectrum/react-corporate-boilerplate.git && cd react-corporate-boilerplate && npm i && npm start`