import React from 'react';

export const App = () => (
    <section>Hello</section>
);
